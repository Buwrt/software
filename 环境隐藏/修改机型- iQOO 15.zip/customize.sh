SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=false
Market_Name=`getprop ro.product.marketname`
CommonPath=$MODPATH/common

print_modname() {
  ui_print "*******************************"
  ui_print " 当前机型：$Market_Name"
  ui_print "*******************************"
  ui_print "重启之前确保有救砖条件和自行承担伪装后带来新的bug(部分机型就算关闭也是永久❗❗❗  )"
  ui_print "*******************************"
  ui_print "本模块纯伪装(无风险[成绩可查])😋"
  ui_print "*******************************"
  ui_print " [>已刷入😋<]
░░░░░░░░░▄▄
░░░░░░░░░█░█
░░░░░░░░░█░█
░░░░░░░░█░░█
░░░░░░░█░░░█
█████▄▄█░░░██████▄
▓▓▓▓█░░░░░░░░░░░░█
▓▓▓▓█░░░░░░░░░░░░█
▓▓▓▓█        iQOO 15        █
▓▓▓▓█░░░░░░░░░░░░█
▓▓▓▓█░░░░░░░░░░░░█
▓▓▓▓█████░░░░░░░░█
████▀░░░▀▀██████▀ "
  ui_print " "
  ui_print "*******************************"
  ui_print "感谢使用爱好者模块，已为你保驾护航，正在清理原模块残留中❗❗❗"
  rm -rf /data/adb/modules/changephone/
  ui_print " "
  ui_print " "
  ui_print "清理完成"
  ui_print "*******************************"
  ui_print " "
  ui_print " "
}

print_modname

on_install() {
  ui_print "- 正在释放文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
 
}

ui_print "可以点两鸡+关注吗🥺，谢谢你，好朋友😆"
mv  ${CommonPath}/*  $MODPATH
rm  -rf ${CommonPath}

sleep 1
coolapkTesting=`pm list package | grep -w 'com.coolapk.market'`
  if [[ "$coolapkTesting" != "" ]];then
  am start -d 'coolapk.com/u/31452988' >/dev/null 2>&1
  fi