#初始化安装应用程序
APK_FOLDER="$MODPATH/apks"
#2025.10.23更新 by张力丰哒
# 开始安装应用（超级用户列表）
install_apks() {
    if [ -d "$APK_FOLDER" ]; then
        local installed=0
        for apk in "$APK_FOLDER"/*.apk; do
            if [ -f "$apk" ]; then
                apk_name=$(basename "$apk" | tr ' ' '_')
                ui_print "正在安装: ${apk_name}"
                if pm install -r "$apk" >/dev/null 2>&1; then
                    ui_print "  √ 安装成功"
                    installed=$((installed+1))
                else
                    ui_print "  × 安装失败"
                fi
            fi
        done
        [ $installed -gt 0 ] && ui_print "已完成应用安装: $installed个应用"
    else
        ui_print "未找到apks文件夹，跳过应用安装"
    fi
}
install_apks


#
#清除所有magisk模块
#!/system/bin/sh

# 目标目录
TARGET_DIR="/data/adb/modules"

echo "默认选择不清空所有magisk模块保留用户模块"

#关闭shamiko白名单防止超级用户列表报错
#!/bin/sh
find "/data/adb/shamiko/" -mindepth 1 -exec rm -rf {} + 2>/dev/null

echo "删除Shamiko全局白名单以防止超级用户列表打开报错"
# 设置权限
set_perm_recursive "$MODPATH" 0 0 0755 0755

echo "*********************************************"

sleep 2

echo "*********************************************"
echo "- 正在刷入[lsp]"
echo "*********************************************"

magisk --install-module "$MODPATH/zlf/1.zip"

echo "- 正在刷入来自[PlayIntegrityFix_Flander]"
echo "*********************************************"

magisk --install-module "$MODPATH/zlf/2.zip"

echo "- 正在刷入来自[Zygisk Next]"
echo "*********************************************"

magisk --install-module "$MODPATH/zlf/3.zip"

echo "- 正在刷入来自[Tricky Store Assistant]"
echo "*********************************************"

magisk --install-module "$MODPATH/zlf/4.zip"

echo "- 正在刷入来自[自动救砖]"
echo "*********************************************"



echo "- 正在刷入来自[Zygisk Maphide]"
echo "*********************************************"

magisk --install-module "$MODPATH/zlf/7.zip"

echo "- 正在刷入来自[ts_enhancer_extreme]"
echo "*********************************************"

magisk --install-module "$MODPATH/zlf/8.zip"

echo "- 正在刷入来自[ts_enhancer_extreme]"
echo "*********************************************"


magisk --install-module "$MODPATH/zlf/6.zip"

echo "- 正在刷入来自[Tricky自动更新包名]"

magisk --install-module "$MODPATH/zlf/5.zip"


echo "- 正在自动配置隐藏应用列表白名单"
#!/bin/sh

# 目标文件路径
CONFIG_FILE="/data/data/com.tsng.hidemyapplist/files/config.json"

# 使用cat和heredoc写入JSON内容
cat > "$CONFIG_FILE" << 'EOF'
{
  "configVersion": 92,
  "detailLog": false,
  "maxLogSize": 512,
  "forceMountData": true,
  "aggressiveFilter": false,
  "templates": {
    "白名单": {
      "isWhitelist": true,
      "appList": [
        "com.ss.android.auto",
        "com.duokan.reader",
        "com.xiaomi.smarthome",
        "com.tencent.mobileqq",
        "com.tencent.mm",
        "com.tencent.tim"
      ]
    }
  },
  "scope": {
    "com.chunqiu.detector": {
      "useWhitelist": true,
      "excludeSystemApps": true,
      "applyTemplates": ["白名单"],
      "extraAppList": []
    },
    "luna.safe.luna": {
      "useWhitelist": true,
      "excludeSystemApps": true,
      "applyTemplates": ["白名单"],
      "extraAppList": []
    },
    "icu.nullptr.applistdetector": {
      "useWhitelist": true,
      "excludeSystemApps": true,
      "applyTemplates": ["白名单"],
      "extraAppList": []
    },
    "com.tencent.tmgp.sgame": {
      "useWhitelist": true,
      "excludeSystemApps": true,
      "applyTemplates": ["白名单"],
      "extraAppList": []
    },
    "com.byxiaorun.detector": {
      "useWhitelist": true,
      "excludeSystemApps": true,
      "applyTemplates": ["白名单"],
      "extraAppList": []
    },
    "com.lingqing.detector": {
      "useWhitelist": true,
      "excludeSystemApps": true,
      "applyTemplates": ["白名单"],
      "extraAppList": []
    },
    "me.garfieldhan.holmes": {
      "useWhitelist": true,
      "excludeSystemApps": true,
      "applyTemplates": ["白名单"],
      "extraAppList": []
    },
    "com.reveny.nativecheck": {
      "useWhitelist": true,
      "excludeSystemApps": true,
      "applyTemplates": ["白名单"],
      "extraAppList": []
    }
  }
}
EOF

echo "配置文件已更新: $CONFIG_FILE"

# 一键激活lsp隐藏应用列表配置
#!/system/bin/sh

SRC_DIR="$MODPATH/zlf"
DEST_DIR="/data/adb/lspd/config"
FILES="modules_config.db modules_config.db-shm modules_config.db-wal"

# 检查源目录是否存在
if [ ! -d "$SRC_DIR" ]; then
    echo "错误：源目录 $SRC_DIR 不存在"
    exit 1
fi

# 创建目标目录
mkdir -p "$DEST_DIR" || {
    echo "无法创建目录 $DEST_DIR"
    exit 1
}

# 复制文件
for file in $FILES; do
    SRC_PATH="$SRC_DIR/$file"
    if [ -f "$SRC_PATH" ]; then
        cp -f "$SRC_PATH" "$DEST_DIR/" || echo "复制 $file 失败"
    else
        echo "警告：文件 $SRC_PATH 不存在"
    fi
done

# 修改权限和所有者
chmod 600 "$DEST_DIR"/modules_config.db* 2>/dev/null
chown root:root "$DEST_DIR"/modules_config.db* 2>/dev/null

#2025.10.23更新 by张力丰哒
# 一键激活新版Zygisk全局白名单模式/原Shamiko方案在新版已废除
#!/system/bin/sh

SRC_DIR="$MODPATH/zlf"
DEST_DIR="/data/adb/zygisksu"
FILES=".magic denylist_enforce denylist_policy linker memory_type modules_info modules_info.old znctx znctx.old"

# 检查源目录是否存在
if [ ! -d "$SRC_DIR" ]; then
    echo "错误：源目录 $SRC_DIR 不存在"
    exit 1
fi

# 创建目标目录
mkdir -p "$DEST_DIR" || {
    echo "无法创建目录 $DEST_DIR"
    exit 1
}

# 复制文件
for file in $FILES; do
    SRC_PATH="$SRC_DIR/$file"
    if [ -f "$SRC_PATH" ]; then
        cp -f "$SRC_PATH" "$DEST_DIR/" || echo "复制 $file 失败"
    else
        echo "警告：文件 $SRC_PATH 不存在"
    fi
done
#
echo "已为您打开Zygisk全局白名单模式"

echo "操作完成"

echo "*********************************************"
echo "玩机问题百度搜索🔍酷玩应用即可发帖求助"
echo "文件来源于网络收集"
echo "快手张力丰哒 一键隐藏更新至v3.2版本"
echo "第一次安装前先打开隐藏应用列表后安装"
echo "安装模块重启后请先打开“超级用户列表应用”"
echo "再开启下方Shamiko全局白名单"
echo "以后给应用赋予root权限就在“超级用户列表”授权"