MODDIR=${0%/*}
mount --bind $MODDIR/my_product/media/bootanimation/ /my_product/media/bootanimation/