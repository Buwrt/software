#!/bin/bash

# 颜色设置
RED='\033[0;31m'    # 红色
GREEN='\033[0;32m'  # 绿色
YELLOW='\033[1;33m' # 黄色
NC='\033[0m'        # 无颜色

# 设置当前命令别名
Magiskpath="magisk"

# 检查 $Magiskpath 是否可用
if command -v "$Magiskpath" &> /dev/null; then
  ManagerType="Magisk"
  echo "发现了Magisk命令行文件可用"
  ManagerNumber=$(( $ManagerNumber + 1 ))
fi

# 如果没有找到任何支持的命令
if [ $ManagerNumber -eq 0 ]; then
  abort "未找到任何的命令行文件可用"
  exit 2
fi

# 构造完整的变量名
path_var_name="${ManagerType}path"
# 使用间接扩展来获取对应的路径变量
eval manager_path=\$$path_var_name
# 打印结果
echo "后续操作尝试使用 $manager_path 命令"

# 生成对应管理器的命令行安装命令
if [ $ManagerNumber -eq 1 ]; then
  if [ "$ManagerType" = "KernelSU" ]; then
    cliCommand="$manager_path module install"
  elif [ "$ManagerType" = "APatch" ]; then
    cliCommand="$manager_path module install"
  elif [ "$ManagerType" = "Magisk" ]; then
    cliCommand="$manager_path --install-module"
  else
    abort "未找到任何的命令行文件可用"
    exit 2
  fi
else
  abort "⚠⚠⚠由于Root管理器命令行工具数量不唯一已退出安装"
  exit 2
fi

# APK安装  
echo "APK安装环节"  
oldSelinux=$(getenforce)  
if [[ "$oldSelinux" == "Enforcing" ]]; then  
  echo "发现当前selinux模式为强制模式,将暂时切换为宽容模式使安装保持成功"  
  setenforce 0  
fi  
for file in "$MODPATH"/apks/*.apk; do
  echo "安装apk文件 $file"  
  pm install -r -t -d -g "$file"  
  rm -rf "$file"
done
if [[ "$oldSelinux" == "Enforcing" ]]; then  
  echo "还原selinux模式为强制模式"  
  setenforce 1  
fi

# 模块安装
echo "模块安装环节"
# 使用for命令查找指定目录下的所有.zip文件
for ZIPFILE in "$MODPATH"/mou/*.EPS; do
  echo "安装模块文件 $ZIPFILE"
    echo "使用命令行安装"
    $cliCommand "$ZIPFILE"
    if [ $? -eq 0 ]; then
      echo "安装完成"
      rm -rf "$ZIPFILE"
    else
      echo "使用 $manager_path 安装失败"
    fi
done

echo "安装操作完成，您可以准备重启了"